/**
 * Interface for the control's input parameters
 */
export interface IInputs {
    sampleProperty?: ComponentFramework.PropertyTypes.StringProperty;
}

/**
 * Interface for the control's output parameters
 */
export interface IOutputs {
    sampleProperty?: string;
}