// Mock data service
// This can be replaced with actual API calls in the future

export interface OrgDetails {
  name: string;
  manager: string;
  cin: string;
}

export interface Meeting {
  date: string;
  summary: string;
  type: string;
}

export interface Representative {
  name: string;
  role: string;
  email: string;
  phone: string;
}

export interface MainReason {
  title: string;
  reasons: string;
  meetingType: string;
  representative: string;
  activityId: string;
}

export interface FollowUpAction {
  date: string;
  action: string;
  status: string;
  priority: string;
  assignee: string;
}

export interface RMAction {
  date: string;
  action: string;
  customer: string;
  status: string;
  nextSteps: string;
}

export interface CustomerSupplier {
  name: string;
  type: string;
  relationship: string;
  creditTerms: string;
  annualValue: string;
  riskLevel: string;
}

export interface RiskMitigation {
  riskArea: string;
  description: string;
  impact: string;
  likelihood: string;
  mitigationStrategy: string;
  status: string;
}

export interface CompanySummary {
  description: string;
  industry: string;
  founded: string;
  headquarters: string;
  employees: string;
  revenue: string;
}

export interface BusinessDescription {
  overview: string;
  businessModel: string;
  marketPosition: string;
  competitiveAdvantage: string;
  growthStrategy: string;
}

export interface OrganizationDetail {
  category: string;
  value: string;
  lastUpdated: string;
}

export interface ManagementInfo {
  name: string;
  position: string;
  experience: string;
  expertise: string;
  achievements: string;
}

export interface IndustryOutlook {
  aspect: string;
  details: {
    growth?: string;
    challenges?: string;
  };
}

class DataService {
  getOrgDetails(): OrgDetails {
    return {
      name: "Global Solutions Inc.",
      manager: "John Smith",
      cin: "L12345AB2024PLC098765"
    };
  }

  getMeetings(): Meeting[] {
    return [
      {
        date: "2024-03-15",
        summary: "Quarterly business review",
        type: "Strategic"
      },
      {
        date: "2024-03-10",
        summary: "Technical implementation meeting",
        type: "Technical"
      },
      {
        date: "2024-03-05",
        summary: "Sales pipeline review",
        type: "Sales"
      }
    ];
  }

  getRepresentatives(): Representative[] {
    return [
      {
        name: "Sarah Johnson",
        role: "Account Executive",
        email: "sarah.j@example.com",
        phone: "+1-555-0123"
      },
      {
        name: "Michael Chen",
        role: "Technical Lead",
        email: "michael.c@example.com",
        phone: "+1-555-0124"
      }
    ];
  }

  getMainReasons(): MainReason[] {
    return [
      {
        title: "Business Growth",
        reasons: "Expansion into new markets",
        meetingType: "Strategic",
        representative: "Sarah Johnson",
        activityId: "BG-001"
      },
      {
        title: "Technical Integration",
        reasons: "System upgrade planning",
        meetingType: "Technical",
        representative: "Michael Chen",
        activityId: "TI-001"
      }
    ];
  }

  getFollowUpActions(): FollowUpAction[] {
    return [
      {
        date: "2024-03-20",
        action: "Market analysis report",
        status: "In Progress",
        priority: "High",
        assignee: "Sarah Johnson"
      },
      {
        date: "2024-03-25",
        action: "Technical specification review",
        status: "Pending",
        priority: "Medium",
        assignee: "Michael Chen"
      },
      {
        date: "2024-03-15",
        action: "Client presentation",
        status: "Completed",
        priority: "High",
        assignee: "Sarah Johnson"
      }
    ];
  }

  getRMActions(): RMAction[] {
    return [
      {
        date: "2024-03-22",
        action: "Follow-up meeting",
        customer: "Global Solutions Inc.",
        status: "Scheduled",
        nextSteps: "Prepare agenda"
      },
      {
        date: "2024-03-18",
        action: "Contract review",
        customer: "Global Solutions Inc.",
        status: "Completed",
        nextSteps: "Send final draft"
      }
    ];
  }

  getCustomerSuppliers(): CustomerSupplier[] {
    return [
      {
        name: "TechCorp",
        type: "Customer",
        relationship: "Strategic",
        creditTerms: "Net 30",
        annualValue: "$500K",
        riskLevel: "Low"
      },
      {
        name: "SupplyTech",
        type: "Supplier",
        relationship: "Preferred",
        creditTerms: "Net 45",
        annualValue: "$300K",
        riskLevel: "Medium"
      }
    ];
  }

  getRiskMitigations(): RiskMitigation[] {
    return [
      {
        riskArea: "Market",
        description: "Competition increase",
        impact: "High",
        likelihood: "Medium",
        mitigationStrategy: "Product differentiation",
        status: "In Progress"
      },
      {
        riskArea: "Technical",
        description: "System integration",
        impact: "Medium",
        likelihood: "Low",
        mitigationStrategy: "Enhanced testing",
        status: "Ongoing"
      },
      {
        riskArea: "Financial",
        description: "Currency fluctuation",
        impact: "High",
        likelihood: "High",
        mitigationStrategy: "Hedging strategy",
        status: "Planned"
      }
    ];
  }

  getCompanySummary(): CompanySummary {
    return {
      description: "Leading technology solutions provider",
      industry: "Technology",
      founded: "2010",
      headquarters: "San Francisco",
      employees: "500+",
      revenue: "$50M+"
    };
  }

  getBusinessDescription(): BusinessDescription {
    return {
      overview: "Global technology solutions provider",
      businessModel: "B2B SaaS",
      marketPosition: "Market Leader",
      competitiveAdvantage: "Innovative Technology",
      growthStrategy: "Market Expansion"
    };
  }

  getOrganizationDetails(): OrganizationDetail[] {
    return [
      {
        category: "Legal Structure",
        value: "Corporation",
        lastUpdated: "2024-01-01"
      },
      {
        category: "Regulatory Compliance",
        value: "ISO 27001",
        lastUpdated: "2024-02-01"
      }
    ];
  }

  getManagementInfo(): ManagementInfo[] {
    return [
      {
        name: "John Smith",
        position: "CEO",
        experience: "15+ years",
        expertise: "Strategy",
        achievements: "Company growth 200%"
      }
    ];
  }

  getIndustryOutlooks(): IndustryOutlook[] {
    return [
      {
        aspect: "Market Growth",
        details: {
          growth: "15% YoY",
          challenges: "Competitive market"
        }
      }
    ];
  }
}

export const dataService = new DataService();