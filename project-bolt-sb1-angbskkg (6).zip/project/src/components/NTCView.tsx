import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Paper,
  Typography,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Box,
  Card,
  CardContent,
  Link
} from '@material-ui/core';
import {
  Building2,
  Users,
  TrendingUp,
  AlertTriangle,
  LineChart,
  BarChart,
  PieChart,
  ArrowUpRight
} from 'lucide-react';
import { motion } from 'framer-motion';

const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      marginBottom: theme.spacing(4),
    },
  },
  paper: {
    borderRadius: theme.shape.borderRadius,
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
  },
  section: {
    padding: theme.spacing(3),
  },
  sectionHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(2),
    marginBottom: theme.spacing(3),
  },
  icon: {
    color: theme.palette.primary.main,
  },
  tableContainer: {
    margin: 0,
  },
  chip: {
    borderRadius: theme.shape.borderRadius,
    '&.High': {
      backgroundColor: '#fee2e2',
      color: '#991b1b',
    },
    '&.Medium': {
      backgroundColor: '#fef9c3',
      color: '#854d0e',
    },
    '&.Low': {
      backgroundColor: '#dbeafe',
      color: '#1e40af',
    },
  },
  card: {
    height: '100%',
    transition: 'transform 0.2s ease-in-out',
    '&:hover': {
      transform: 'translateY(-4px)',
    },
  },
  outlookCard: {
    backgroundColor: theme.palette.background.default,
    marginBottom: theme.spacing(2),
  },
  detailsGrid: {
    marginTop: theme.spacing(2),
  },
  detailItem: {
    marginBottom: theme.spacing(2),
  },
  detailLabel: {
    color: theme.palette.text.secondary,
    marginBottom: theme.spacing(0.5),
  },
  detailValue: {
    fontWeight: 500,
  },
  managementCard: {
    backgroundColor: theme.palette.background.default,
  },
}));

// ... (keep all the existing interfaces)

const NTCView: React.FC<NTCViewProps> = ({
  businessDescription,
  customerSuppliers,
  organizationDetails,
  riskMitigations,
  managementInfo,
  industryOutlooks
}) => {
  const classes = useStyles();

  const getOutlookIcon = (aspect: string) => {
    switch (aspect) {
      case 'Latest Industry Performance':
        return <BarChart className={classes.icon} size={20} />;
      case 'Market Share/Competition':
        return <PieChart className={classes.icon} size={20} />;
      case 'Outlook & Strategy':
        return <ArrowUpRight className={classes.icon} size={20} />;
      default:
        return <TrendingUp className={classes.icon} size={20} />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={classes.root}
    >
      <Grid container spacing={4}>
        {/* Business Description */}
        <Grid item xs={12}>
          <Paper className={classes.paper}>
            <Box className={classes.section}>
              <div className={classes.sectionHeader}>
                <Building2 className={classes.icon} size={24} />
                <Typography variant="h6">Business Description</Typography>
              </div>
              <Typography paragraph>{businessDescription.overview}</Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Card className={classes.card}>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>Business Model</Typography>
                      <Typography>{businessDescription.businessModel}</Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Card className={classes.card}>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>Market Position</Typography>
                      <Typography>{businessDescription.marketPosition}</Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Card className={classes.card}>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>Competitive Advantage</Typography>
                      <Typography>{businessDescription.competitiveAdvantage}</Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Card className={classes.card}>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>Growth Strategy</Typography>
                      <Typography>{businessDescription.growthStrategy}</Typography>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </Box>
          </Paper>
        </Grid>

        {/* Customer/Supplier Details */}
        <Grid item xs={12}>
          <Paper className={classes.paper}>
            <Box className={classes.section}>
              <div className={classes.sectionHeader}>
                <Users className={classes.icon} size={24} />
                <Typography variant="h6">Customer/Supplier Details</Typography>
              </div>
              <TableContainer className={classes.tableContainer}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Name</TableCell>
                      <TableCell>Type</TableCell>
                      <TableCell>Relationship</TableCell>
                      <TableCell>Credit Terms</TableCell>
                      <TableCell>Annual Value</TableCell>
                      <TableCell>Risk Level</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {customerSuppliers.map((entity, index) => (
                      <TableRow key={index} hover>
                        <TableCell>{entity.name}</TableCell>
                        <TableCell>{entity.type}</TableCell>
                        <TableCell>{entity.relationship}</TableCell>
                        <TableCell>{entity.creditTerms}</TableCell>
                        <TableCell>{entity.annualValue}</TableCell>
                        <TableCell>
                          <Chip
                            label={entity.riskLevel}
                            size="small"
                            className={`${classes.chip} ${entity.riskLevel}`}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          </Paper>
        </Grid>

        {/* Organization Details */}
        <Grid item xs={12}>
          <Paper className={classes.paper}>
            <Box className={classes.section}>
              <div className={classes.sectionHeader}>
                <Building2 className={classes.icon} size={24} />
                <Typography variant="h6">Organization Details</Typography>
              </div>
              <Grid container spacing={3}>
                {organizationDetails.map((detail, index) => (
                  <Grid item xs={12} md={4} key={index}>
                    <Card className={classes.card}>
                      <CardContent>
                        <Typography color="textSecondary" gutterBottom>
                          {detail.category}
                        </Typography>
                        <Typography variant="h6">{detail.value}</Typography>
                        <Typography variant="caption" color="textSecondary">
                          Last updated: {detail.lastUpdated}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </Box>
          </Paper>
        </Grid>

        {/* Risk and Mitigation Analysis */}
        <Grid item xs={12}>
          <Paper className={classes.paper}>
            <Box className={classes.section}>
              <div className={classes.sectionHeader}>
                <AlertTriangle className={classes.icon} size={24} />
                <Typography variant="h6">Risk and Mitigation Analysis</Typography>
              </div>
              <TableContainer className={classes.tableContainer}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Risk Area</TableCell>
                      <TableCell>Description</TableCell>
                      <TableCell>Impact</TableCell>
                      <TableCell>Likelihood</TableCell>
                      <TableCell>Mitigation Strategy</TableCell>
                      <TableCell>Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {riskMitigations.map((risk, index) => (
                      <TableRow key={index} hover>
                        <TableCell>{risk.riskArea}</TableCell>
                        <TableCell>{risk.description}</TableCell>
                        <TableCell>
                          <Chip
                            label={risk.impact}
                            size="small"
                            className={`${classes.chip} ${risk.impact}`}
                          />
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={risk.likelihood}
                            size="small"
                            className={`${classes.chip} ${risk.likelihood}`}
                          />
                        </TableCell>
                        <TableCell>{risk.mitigationStrategy}</TableCell>
                        <TableCell>
                          <Chip
                            label={risk.status}
                            size="small"
                            className={`${classes.chip} ${risk.status.replace(/\s+/g, '')}`}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          </Paper>
        </Grid>

        {/* Management Information */}
        <Grid item xs={12}>
          <Paper className={classes.paper}>
            <Box className={classes.section}>
              <div className={classes.sectionHeader}>
                <Users className={classes.icon} size={24} />
                <Typography variant="h6">Management Information</Typography>
              </div>
              <Grid container spacing={3}>
                {managementInfo.map((manager, index) => (
                  <Grid item xs={12} md={6} key={index}>
                    <Card className={classes.managementCard}>
                      <CardContent>
                        <Typography variant="h6">{manager.name}</Typography>
                        <Typography color="primary" gutterBottom>{manager.position}</Typography>
                        <Grid container spacing={2} className={classes.detailsGrid}>
                          <Grid item xs={12}>
                            <Typography variant="subtitle2" className={classes.detailLabel}>
                              Experience
                            </Typography>
                            <Typography className={classes.detailValue}>
                              {manager.experience}
                            </Typography>
                          </Grid>
                          <Grid item xs={12}>
                            <Typography variant="subtitle2" className={classes.detailLabel}>
                              Expertise
                            </Typography>
                            <Typography className={classes.detailValue}>
                              {manager.expertise}
                            </Typography>
                          </Grid>
                          <Grid item xs={12}>
                            <Typography variant="subtitle2" className={classes.detailLabel}>
                              Key Achievements
                            </Typography>
                            <Typography className={classes.detailValue}>
                              {manager.achievements}
                            </Typography>
                          </Grid>
                        </Grid>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </Box>
          </Paper>
        </Grid>

        {/* Industry Outlook */}
        <Grid item xs={12}>
          <Paper className={classes.paper}>
            <Box className={classes.section}>
              <div className={classes.sectionHeader}>
                <TrendingUp className={classes.icon} size={24} />
                <Typography variant="h6">Industry Outlook</Typography>
              </div>
              <Grid container spacing={3}>
                {industryOutlooks.map((outlook, index) => (
                  <Grid item xs={12} key={index}>
                    <Card className={classes.outlookCard}>
                      <CardContent>
                        <div className={classes.sectionHeader}>
                          {getOutlookIcon(outlook.aspect)}
                          <Typography variant="h6">{outlook.aspect}</Typography>
                        </div>
                        <Grid container spacing={3}>
                          {outlook.aspect === 'Latest Industry Performance' && (
                            <>
                              <Grid item xs={12} md={6}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Market Size
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.revenue}
                                </Typography>
                              </Grid>
                              <Grid item xs={12} md={6}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Growth
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.growth}
                                </Typography>
                              </Grid>
                              <Grid item xs={12}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Key Drivers
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.keyDrivers}
                                </Typography>
                              </Grid>
                              <Grid item xs={12}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Challenges
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.challenges}
                                </Typography>
                              </Grid>
                            </>
                          )}
                          {outlook.aspect === 'Market Share/Competition' && (
                            <>
                              <Grid item xs={12} md={6}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Market Position
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.marketPosition}
                                </Typography>
                              </Grid>
                              <Grid item xs={12} md={6}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Market Share
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.marketShare}
                                </Typography>
                              </Grid>
                              <Grid item xs={12}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Competitors
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.competitors}
                                </Typography>
                              </Grid>
                              <Grid item xs={12}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Competitive Edge
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.competitiveEdge}
                                </Typography>
                              </Grid>
                            </>
                          )}
                          {outlook.aspect === 'Outlook & Strategy' && (
                            <>
                              <Grid item xs={12} md={4}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Short-term Strategy
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.shortTerm}
                                </Typography>
                              </Grid>
                              <Grid item xs={12} md={4}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Medium-term Strategy
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.mediumTerm}
                                </Typography>
                              </Grid>
                              <Grid item xs={12} md={4}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Long-term Vision
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.longTerm}
                                </Typography>
                              </Grid>
                              <Grid item xs={12} md={6}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Risks
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.risks}
                                </Typography>
                              </Grid>
                              <Grid item xs={12} md={6}>
                                <Typography variant="subtitle2" className={classes.detailLabel}>
                                  Opportunities
                                </Typography>
                                <Typography className={classes.detailValue}>
                                  {outlook.details.opportunities}
                                </Typography>
                              </Grid>
                            </>
                          )}
                        </Grid>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </motion.div>
  );
};

export default NTCView;