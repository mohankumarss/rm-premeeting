import React, { useState } from 'react';
import { 
  makeStyles,
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Hidden,
  Divider
} from '@material-ui/core';
import {
  Business as BuildingIcon,
  Menu as MenuIcon,
  Close as CloseIcon
} from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  appBar: {
    backgroundColor: theme.palette.background.paper,
    color: theme.palette.text.primary,
  },
  toolbar: {
    display: 'flex',
    justifyContent: 'space-between',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(2),
  },
  orgInfo: {
    display: 'flex',
    flexDirection: 'column',
  },
  subInfo: {
    display: 'flex',
    gap: theme.spacing(2),
    color: theme.palette.text.secondary,
    fontSize: '0.875rem',
  },
  nav: {
    display: 'flex',
    gap: theme.spacing(2),
  },
  navButton: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(1),
  },
  activeNavButton: {
    backgroundColor: theme.palette.primary.light,
    color: theme.palette.primary.main,
  },
  drawerPaper: {
    width: 240,
  },
}));

interface NavItem {
  name: string;
  icon: React.ReactNode;
}

interface HeaderProps {
  orgName: string;
  manager: string;
  cin: string;
  navItems: NavItem[];
  onNavClick: (view: string) => void;
  activeView: string;
}

const Header: React.FC<HeaderProps> = ({
  orgName,
  manager,
  cin,
  navItems,
  onNavClick,
  activeView,
}) => {
  const classes = useStyles();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleNavClick = (name: string) => {
    onNavClick(name);
    setMobileOpen(false);
  };

  const drawer = (
    <div>
      <List>
        {navItems.map((item) => (
          <ListItem
            button
            key={item.name}
            onClick={() => handleNavClick(item.name)}
            selected={activeView === item.name}
          >
            <ListItemIcon>{item.icon}</ListItemIcon>
            <ListItemText primary={item.name} />
          </ListItem>
        ))}
      </List>
    </div>
  );

  return (
    <div className={classes.root}>
      <AppBar position="static" elevation={1} className={classes.appBar}>
        <Toolbar className={classes.toolbar}>
          <div className={classes.logo}>
            <BuildingIcon color="primary" />
            <div className={classes.orgInfo}>
              <Typography variant="h6">{orgName}</Typography>
              <div className={classes.subInfo}>
                <Typography variant="body2">{manager}</Typography>
                <Hidden xsDown>
                  <Typography variant="body2">|</Typography>
                  <Typography variant="body2">{cin}</Typography>
                </Hidden>
              </div>
            </div>
          </div>

          <Hidden smDown>
            <div className={classes.nav}>
              {navItems.map((item) => (
                <Button
                  key={item.name}
                  className={`${classes.navButton} ${
                    activeView === item.name ? classes.activeNavButton : ''
                  }`}
                  onClick={() => handleNavClick(item.name)}
                  startIcon={item.icon}
                >
                  {item.name}
                </Button>
              ))}
            </div>
          </Hidden>

          <Hidden mdUp>
            <IconButton
              edge="end"
              color="inherit"
              aria-label="menu"
              onClick={handleDrawerToggle}
            >
              <MenuIcon />
            </IconButton>
          </Hidden>
        </Toolbar>
      </AppBar>

      <Hidden mdUp>
        <Drawer
          variant="temporary"
          anchor="right"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          classes={{
            paper: classes.drawerPaper,
          }}
          ModalProps={{
            keepMounted: true,
          }}
        >
          {drawer}
        </Drawer>
      </Hidden>
    </div>
  );
};

export default Header;