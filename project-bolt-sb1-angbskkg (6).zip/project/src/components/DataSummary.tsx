import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { motion } from 'framer-motion';
import { makeStyles } from '@material-ui/core/styles';
import { Paper, Typography, Grid } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(3),
  },
  chartContainer: {
    width: '100%',
    height: 300,
    marginBottom: theme.spacing(4),
  },
  paper: {
    padding: theme.spacing(3),
    height: '100%',
  },
  metricsContainer: {
    marginTop: theme.spacing(4),
  },
  metricItem: {
    padding: theme.spacing(2),
    backgroundColor: theme.palette.primary.light,
    borderRadius: theme.shape.borderRadius,
    color: theme.palette.primary.contrastText,
  },
  metricLabel: {
    color: 'rgba(255, 255, 255, 0.8)',
    marginBottom: theme.spacing(1),
  },
  metricValue: {
    fontSize: '1.5rem',
    fontWeight: 600,
  },
}));

interface DataSummaryProps {
  meetings: any[];
  representatives: any[];
  mainReasons: any[];
  followUpActions: any[];
  rmActions: any[];
  customerSuppliers: any[];
  riskMitigations: any[];
}

const COLORS = ['#0284c7', '#0ea5e9', '#38bdf8', '#7dd3fc', '#bae6fd'];

const DataSummary: React.FC<DataSummaryProps> = ({
  meetings,
  representatives,
  mainReasons,
  followUpActions,
  rmActions,
  customerSuppliers,
  riskMitigations,
}) => {
  const classes = useStyles();

  const meetingTypeData = meetings.reduce((acc: any, meeting) => {
    const existingType = acc.find((item: any) => item.name === meeting.type);
    if (existingType) {
      existingType.value++;
    } else {
      acc.push({ name: meeting.type, value: 1 });
    }
    return acc;
  }, []);

  const riskData = riskMitigations.map(risk => ({
    name: risk.riskArea,
    impact: risk.impact === 'High' ? 3 : risk.impact === 'Medium' ? 2 : 1,
    likelihood: risk.likelihood === 'High' ? 3 : risk.likelihood === 'Medium' ? 2 : 1,
  }));

  const actionStatusData = [...followUpActions, ...rmActions].reduce((acc: any, action) => {
    const existingStatus = acc.find((item: any) => item.name === action.status);
    if (existingStatus) {
      existingStatus.value++;
    } else {
      acc.push({ name: action.status, value: 1 });
    }
    return acc;
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={classes.root}
    >
      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <Paper className={classes.paper}>
            <Typography variant="h6" gutterBottom>Meeting Types Distribution</Typography>
            <div className={classes.chartContainer}>
              <ResponsiveContainer>
                <PieChart>
                  <Pie
                    data={meetingTypeData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  >
                    {meetingTypeData.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper className={classes.paper}>
            <Typography variant="h6" gutterBottom>Risk Analysis</Typography>
            <div className={classes.chartContainer}>
              <ResponsiveContainer>
                <BarChart data={riskData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="impact" fill="#0284c7" name="Impact" />
                  <Bar dataKey="likelihood" fill="#38bdf8" name="Likelihood" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper className={classes.paper}>
            <Typography variant="h6" gutterBottom>Action Status Distribution</Typography>
            <div className={classes.chartContainer}>
              <ResponsiveContainer>
                <PieChart>
                  <Pie
                    data={actionStatusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  >
                    {actionStatusData.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper className={classes.paper}>
            <Typography variant="h6" gutterBottom>Key Metrics</Typography>
            <Grid container spacing={2} className={classes.metricsContainer}>
              <Grid item xs={6}>
                <div className={classes.metricItem}>
                  <Typography variant="body2" className={classes.metricLabel}>
                    Total Representatives
                  </Typography>
                  <Typography className={classes.metricValue}>
                    {representatives.length}
                  </Typography>
                </div>
              </Grid>
              <Grid item xs={6}>
                <div className={classes.metricItem}>
                  <Typography variant="body2" className={classes.metricLabel}>
                    Total Meetings
                  </Typography>
                  <Typography className={classes.metricValue}>
                    {meetings.length}
                  </Typography>
                </div>
              </Grid>
              <Grid item xs={6}>
                <div className={classes.metricItem}>
                  <Typography variant="body2" className={classes.metricLabel}>
                    Active Follow-ups
                  </Typography>
                  <Typography className={classes.metricValue}>
                    {followUpActions.filter(action => action.status === 'In Progress').length}
                  </Typography>
                </div>
              </Grid>
              <Grid item xs={6}>
                <div className={classes.metricItem}>
                  <Typography variant="body2" className={classes.metricLabel}>
                    Business Partners
                  </Typography>
                  <Typography className={classes.metricValue}>
                    {customerSuppliers.length}
                  </Typography>
                </div>
              </Grid>
            </Grid>
          </Paper>
        </Grid>
      </Grid>
    </motion.div>
  );
};

export default DataSummary;