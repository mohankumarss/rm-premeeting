import React, { useRef } from 'react';
import {
  makeStyles,
  Paper,
  Typography,
  Grid,
  IconButton,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Box,
  Link
} from '@material-ui/core';
import {
  Business as BusinessIcon,
  People as UsersIcon,
  Event as CalendarIcon,
  AttachMoney as DollarIcon,
  Work as BriefcaseIcon,
  Room as MapPinIcon,
  Email as MailIcon,
  Phone as PhoneIcon,
  ChevronLeft,
  ChevronRight
} from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      marginBottom: theme.spacing(4),
    },
  },
  summaryCard: {
    padding: theme.spacing(3),
  },
  summaryGrid: {
    marginTop: theme.spacing(3),
  },
  infoItem: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(2),
  },
  tableContainer: {
    marginTop: theme.spacing(2),
  },
  chip: {
    borderRadius: theme.shape.borderRadius,
  },
  representativesSection: {
    position: 'relative',
  },
  scrollContainer: {
    display: 'flex',
    overflowX: 'auto',
    gap: theme.spacing(2),
    padding: theme.spacing(1),
    scrollBehavior: 'smooth',
    '&::-webkit-scrollbar': {
      display: 'none',
    },
    msOverflowStyle: 'none',
    scrollbarWidth: 'none',
  },
  representativeCard: {
    minWidth: 300,
    flex: '0 0 auto',
  },
  scrollButton: {
    position: 'absolute',
    top: '50%',
    transform: 'translateY(-50%)',
    zIndex: 1,
    backgroundColor: theme.palette.background.paper,
    '&:hover': {
      backgroundColor: theme.palette.action.hover,
    },
  },
  scrollButtonLeft: {
    left: theme.spacing(1),
  },
  scrollButtonRight: {
    right: theme.spacing(1),
  },
  contactLink: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(1),
    color: theme.palette.text.secondary,
    textDecoration: 'none',
    '&:hover': {
      color: theme.palette.primary.main,
    },
  },
}));

interface Meeting {
  date: string;
  summary: string;
  type: string;
}

interface CompanySummary {
  description: string;
  industry: string;
  founded: string;
  headquarters: string;
  employees: string;
  revenue: string;
}

interface Representative {
  name: string;
  role: string;
  email: string;
  phone: string;
}

interface MainReason {
  title: string;
  reasons: string;
  meetingType: string;
  representative: string;
  activityId: string;
}

interface SosViewProps {
  companySummary: CompanySummary;
  meetings: Meeting[];
  representatives: Representative[];
  mainReasons: MainReason[];
}

const SosView: React.FC<SosViewProps> = ({
  companySummary,
  meetings,
  representatives,
  mainReasons,
}) => {
  const classes = useStyles();
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 300;
      const newScrollLeft = scrollContainerRef.current.scrollLeft + (direction === 'left' ? -scrollAmount : scrollAmount);
      scrollContainerRef.current.scrollTo({
        left: newScrollLeft,
        behavior: 'smooth',
      });
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div className={classes.root}>
      {/* Company Summary */}
      <Paper className={classes.summaryCard}>
        <Typography variant="h6" gutterBottom>
          Company Summary
        </Typography>
        <Typography color="textSecondary" paragraph>
          {companySummary.description}
        </Typography>
        
        <Grid container spacing={3} className={classes.summaryGrid}>
          <Grid item xs={12} sm={6} md={4}>
            <div className={classes.infoItem}>
              <BriefcaseIcon color="primary" />
              <div>
                <Typography variant="body2" color="textSecondary">
                  Industry
                </Typography>
                <Typography>{companySummary.industry}</Typography>
              </div>
            </div>
          </Grid>
          
          <Grid item xs={12} sm={6} md={4}>
            <div className={classes.infoItem}>
              <CalendarIcon color="primary" />
              <div>
                <Typography variant="body2" color="textSecondary">
                  Founded
                </Typography>
                <Typography>{companySummary.founded}</Typography>
              </div>
            </div>
          </Grid>
          
          <Grid item xs={12} sm={6} md={4}>
            <div className={classes.infoItem}>
              <MapPinIcon color="primary" />
              <div>
                <Typography variant="body2" color="textSecondary">
                  Headquarters
                </Typography>
                <Typography>{companySummary.headquarters}</Typography>
              </div>
            </div>
          </Grid>
          
          <Grid item xs={12} sm={6} md={4}>
            <div className={classes.infoItem}>
              <UsersIcon color="primary" />
              <div>
                <Typography variant="body2" color="textSecondary">
                  Employees
                </Typography>
                <Typography>{companySummary.employees}</Typography>
              </div>
            </div>
          </Grid>
          
          <Grid item xs={12} sm={6} md={4}>
            <div className={classes.infoItem}>
              <DollarIcon color="primary" />
              <div>
                <Typography variant="body2" color="textSecondary">
                  Annual Revenue
                </Typography>
                <Typography>{companySummary.revenue}</Typography>
              </div>
            </div>
          </Grid>
        </Grid>
      </Paper>

      {/* Main Reasons Table */}
      <Paper>
        <Box p={3}>
          <Typography variant="h6" gutterBottom>
            Main Reasons
          </Typography>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Title</TableCell>
                  <TableCell>Reasons</TableCell>
                  <TableCell>Meeting Type</TableCell>
                  <TableCell>Representative</TableCell>
                  <TableCell>Activity ID</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {mainReasons.map((reason, index) => (
                  <TableRow key={index}>
                    <TableCell>
                      <Typography variant="body2">{reason.title}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" color="textSecondary">
                        {reason.reasons}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={reason.meetingType}
                        size="small"
                        className={classes.chip}
                        color="primary"
                      />
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">{reason.representative}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" color="textSecondary">
                        {reason.activityId}
                      </Typography>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>

      {/* Representatives Section */}
      <Paper className={classes.representativesSection}>
        <Box p={3}>
          <Typography variant="h6" gutterBottom>
            Organization Representatives
          </Typography>
          
          <IconButton
            className={`${classes.scrollButton} ${classes.scrollButtonLeft}`}
            onClick={() => scroll('left')}
            size="small"
          >
            <ChevronLeft />
          </IconButton>
          
          <IconButton
            className={`${classes.scrollButton} ${classes.scrollButtonRight}`}
            onClick={() => scroll('right')}
            size="small"
          >
            <ChevronRight />
          </IconButton>
          
          <div ref={scrollContainerRef} className={classes.scrollContainer}>
            {representatives.map((rep, index) => (
              <Card key={index} className={classes.representativeCard}>
                <CardContent>
                  <Typography variant="h6">{rep.name}</Typography>
                  <Typography color="primary" gutterBottom>
                    {rep.role}
                  </Typography>
                  
                  <Box mt={2}>
                    <Link
                      href={`mailto:${rep.email}`}
                      className={classes.contactLink}
                      component="a"
                    >
                      <MailIcon fontSize="small" />
                      <Typography variant="body2">{rep.email}</Typography>
                    </Link>
                    
                    <Link
                      href={`tel:${rep.phone}`}
                      className={classes.contactLink}
                      component="a"
                    >
                      <PhoneIcon fontSize="small" />
                      <Typography variant="body2">{rep.phone}</Typography>
                    </Link>
                  </Box>
                </CardContent>
              </Card>
            ))}
          </div>
        </Box>
      </Paper>

      {/* Meetings Table */}
      <Paper>
        <Box p={3}>
          <Typography variant="h6" gutterBottom>
            Meeting History
          </Typography>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Date</TableCell>
                  <TableCell>Summary</TableCell>
                  <TableCell>Type</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {meetings.map((meeting, index) => (
                  <TableRow key={index}>
                    <TableCell>
                      <Typography variant="body2">
                        {formatDate(meeting.date)}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" color="textSecondary">
                        {meeting.summary}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={meeting.type}
                        size="small"
                        className={classes.chip}
                        color="primary"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>
    </div>
  );
};

export default SosView;