import { CallRecord, ApiResponse } from '../types';

// Mock data to simulate API responses
const mockCalls: CallRecord[] = [
  {
    id: '1',
    phoneNumber: '+1 (555) 123-4567',
    callDuration: 325, // duration in seconds
    callEndDate: '2025-04-01T14:30:00Z',
    topicsDiscussed: ['Billing', 'Technical Support', 'Upgrade Options'],
    notes: 'Customer was confused about recent billing changes. Explained the new pricing structure.',
    sentiment: 'neutral',
    callType: 'incoming',
    agentName: 'Sarah Johnson',
    transcriptSummary: 'Customer inquired about billing discrepancies and requested technical support for connectivity issues. Also discussed potential service upgrades.',
  },
  {
    id: '2',
    phoneNumber: '+1 (555) 987-6543',
    callDuration: 542,
    callEndDate: '2025-04-01T16:45:00Z',
    topicsDiscussed: ['Account Management', 'Complaints', 'Cancellation'],
    notes: 'Customer was unhappy with service quality. Offered a 3-month discount to retain.',
    sentiment: 'negative',
    callType: 'incoming',
    agentName: 'Michael Torres',
    transcriptSummary: 'Customer expressed frustration with service outages and considered cancellation. Offered retention discount and service improvements.',
  },
  {
    id: '3',
    phoneNumber: '+1 (555) 567-8901',
    callDuration: 187,
    callEndDate: '2025-04-02T09:15:00Z',
    topicsDiscussed: ['New Services', 'Pricing'],
    notes: 'Potential new customer inquiring about service packages and pricing options.',
    sentiment: 'positive',
    callType: 'incoming',
    agentName: 'David Chen',
    transcriptSummary: 'Prospect requested information about premium service packages and expressed interest in the family bundle.',
  },
  {
    id: '4',
    phoneNumber: '+1 (555) 234-5678',
    callDuration: 412,
    callEndDate: '2025-04-02T11:30:00Z',
    topicsDiscussed: ['Technical Support', 'Hardware', 'Troubleshooting'],
    notes: 'Walked through router reset process and confirmed service restoration.',
    sentiment: 'positive',
    callType: 'outgoing',
    agentName: 'Jessica Williams',
    transcriptSummary: 'Follow-up call regarding previously reported connectivity issues. Guided customer through troubleshooting steps successfully.',
  },
  {
    id: '5',
    phoneNumber: '+1 (555) 345-6789',
    callDuration: 278,
    callEndDate: '2025-04-03T13:45:00Z',
    topicsDiscussed: ['Account Management', 'Payment Methods', 'Auto-pay'],
    notes: 'Updated payment method and enrolled customer in auto-pay program.',
    sentiment: 'neutral',
    callType: 'incoming',
    agentName: 'Robert Garcia',
    transcriptSummary: 'Customer requested assistance with updating payment information and enrolling in automated monthly payments.',
  },
  {
    id: '6',
    phoneNumber: '+1 (555) 456-7890',
    callDuration: 631,
    callEndDate: '2025-04-03T15:20:00Z',
    topicsDiscussed: ['Technical Support', 'Software Update', 'User Guide'],
    notes: 'Complex issue with software integration. Escalated to Tier 2 support.',
    sentiment: 'negative',
    callType: 'incoming',
    agentName: 'Emily Davis',
    transcriptSummary: 'Customer reported persistent software issues following recent update. Attempted troubleshooting but required escalation.',
  },
  {
    id: '7',
    phoneNumber: '+1 (555) 678-9012',
    callDuration: 195,
    callEndDate: '2025-04-04T10:10:00Z',
    topicsDiscussed: ['Feedback', 'Service Improvement'],
    notes: 'Customer provided valuable feedback about recent service improvements.',
    sentiment: 'positive',
    callType: 'outgoing',
    agentName: 'James Wilson',
    transcriptSummary: 'Follow-up call to collect feedback on recent service enhancements. Customer reported satisfaction with improvements.',
  },
  {
    id: '8',
    phoneNumber: '+1 (555) 789-0123',
    callDuration: 347,
    callEndDate: '2025-04-04T14:50:00Z',
    topicsDiscussed: ['Billing', 'Discounts', 'Plan Changes'],
    notes: 'Adjusted service plan to better match customer usage patterns.',
    sentiment: 'positive',
    callType: 'incoming',
    agentName: 'Sarah Johnson',
    transcriptSummary: 'Customer requested plan review to reduce monthly costs. Recommended more suitable plan based on usage analysis.',
  },
];

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// API service
export const callsApi = {
  // Get all calls
  async getAllCalls(): Promise<ApiResponse<CallRecord[]>> {
    await delay(800); // Simulate network delay
    return {
      data: mockCalls,
      status: 200,
      message: 'Calls retrieved successfully'
    };
  },

  // Get call by ID
  async getCallById(id: string): Promise<ApiResponse<CallRecord>> {
    await delay(600); // Simulate network delay
    const call = mockCalls.find(call => call.id === id);
    
    if (!call) {
      return {
        data: {} as CallRecord,
        status: 404,
        message: 'Call not found'
      };
    }
    
    return {
      data: call,
      status: 200,
      message: 'Call retrieved successfully'
    };
  }
};