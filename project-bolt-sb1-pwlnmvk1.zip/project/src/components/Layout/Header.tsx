import React from 'react';
import { PhoneCall } from 'lucide-react';
import { Link } from 'react-router-dom';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4 md:justify-start md:space-x-10">
          <div className="flex justify-start lg:w-0 lg:flex-1">
            <Link to="/" className="flex items-center">
              <span className="sr-only">Call Analytics</span>
              <PhoneCall className="h-8 w-8 text-primary-600" />
              <span className="ml-2 text-xl font-semibold text-gray-900">Call Analytics</span>
            </Link>
          </div>
          <nav className="flex space-x-8">
            <Link 
              to="/"
              className="text-base font-medium text-gray-500 hover:text-gray-900 transition-colors"
            >
              Dashboard
            </Link>
            <Link 
              to="/calls"
              className="text-base font-medium text-gray-500 hover:text-gray-900 transition-colors"
            >
              Calls
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;