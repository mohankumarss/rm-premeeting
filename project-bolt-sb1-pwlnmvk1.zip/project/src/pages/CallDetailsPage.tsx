import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Layout from '../components/Layout/Layout';
import { callsApi } from '../services/api';
import { CallRecord } from '../types';
import { ArrowLeft, Volume2, Download, Share2, Mail, Save } from 'lucide-react';
import { formatDuration } from '../utils/formatters';

const CallDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [call, setCall] = useState<CallRecord | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);

  useEffect(() => {
    const fetchCallDetails = async () => {
      if (!id) return;
      
      try {
        setIsLoading(true);
        const response = await callsApi.getCallById(id);
        
        if (response.status === 200) {
          setCall(response.data);
        } else if (response.status === 404) {
          setError('Call not found');
        } else {
          setError('Error fetching call details: ' + response.message);
        }
      } catch (err) {
        setError('An error occurred while fetching the call data.');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchCallDetails();
  }, [id]);

  const handleGoBack = () => {
    navigate(-1);
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="animate-pulse p-6">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </div>
      </Layout>
    );
  }

  if (error || !call) {
    return (
      <Layout>
        <div className="p-6">
          <div className="bg-red-50 border-l-4 border-red-400 p-4">
            <div className="flex">
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Error</h3>
                <div className="mt-2 text-sm text-red-700">
                  <p>{error || 'Call data not available'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={handleGoBack}
            className="inline-flex items-center text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back
          </button>
        </div>

        <div className="bg-white rounded-lg shadow">
          {/* Header */}
          <div className="border-b border-gray-200 p-6">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-xl font-semibold text-gray-900">Call Transcription & Summary</h1>
                <div className="mt-1 text-sm text-gray-500">
                  {call.phoneNumber}
                </div>
              </div>
              <div className="text-sm text-gray-500">
                <div>Call ID: CAL-{id}</div>
                <div>Start: {new Date(call.callEndDate).toLocaleTimeString()}</div>
                <div>Duration: {formatDuration(call.callDuration)}</div>
                <div className="text-green-600 font-medium">Completed</div>
              </div>
            </div>
          </div>

          {/* Audio Player */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center space-x-4">
              <button className="p-2 rounded-full bg-primary-600 text-white">
                <Volume2 className="h-6 w-6" />
              </button>
              <div className="flex-1">
                <div className="h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-2 bg-primary-600 rounded-full" 
                    style={{ width: `${(currentTime / duration) * 100}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>{formatDuration(currentTime)}</span>
                  <span>{formatDuration(duration)}</span>
                </div>
              </div>
              <div className="flex space-x-2">
                <button className="p-2 text-gray-600 hover:text-gray-900">
                  <Download className="h-5 w-5" />
                </button>
                <button className="p-2 text-gray-600 hover:text-gray-900">
                  <Share2 className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-2 divide-x divide-gray-200">
            {/* Left Column - Transcription */}
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-medium text-gray-900">Transcription</h2>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search transcript..."
                    className="w-64 px-4 py-2 border border-gray-300 rounded-md text-sm"
                  />
                </div>
              </div>
              <div className="space-y-4 max-h-[500px] overflow-y-auto">
                {call.transcriptSummary?.split('\n').map((line, index) => (
                  <div key={index} className="text-sm text-gray-700">
                    {line}
                  </div>
                ))}
              </div>
            </div>

            {/* Right Column - AI Summary */}
            <div className="p-6">
              <h2 className="text-lg font-medium text-gray-900 mb-4">AI Summary</h2>
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-900 mb-2">Key Points:</h3>
                  <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
                    {call.topicsDiscussed.map((topic, index) => (
                      <li key={index}>{topic}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900 mb-2">Action Items:</h3>
                  <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
                    <li>Follow up on customer feedback</li>
                    <li>Process refund request</li>
                  </ul>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900 mb-2">Full Summary:</h3>
                  <p className="text-sm text-gray-700">{call.notes}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="border-t border-gray-200 p-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-sm font-medium text-gray-900 mb-2">Actions</h3>
                <div className="flex space-x-2">
                  <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700">
                    <Save className="h-4 w-4 mr-2" />
                    Save to CRM
                  </button>
                  <button className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50">
                    <Mail className="h-4 w-4 mr-2" />
                    Email
                  </button>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-500">CRM Destination:</span>
                <select className="block w-48 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md">
                  <option>Customer Record</option>
                  <option>Support Ticket</option>
                  <option>Sales Lead</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default CallDetailsPage;