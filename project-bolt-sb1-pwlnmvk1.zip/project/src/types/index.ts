export interface CallRecord {
  id: string;
  phoneNumber: string;
  callDuration: number;
  callEndDate: string;
  topicsDiscussed: string[];
  notes?: string;
  sentiment?: 'positive' | 'neutral' | 'negative';
  callType?: 'incoming' | 'outgoing';
  agentName?: string;
  recordingUrl?: string;
  transcriptSummary?: string;
}

export interface ApiResponse<T> {
  data: T;
  status: number;
  message: string;
}