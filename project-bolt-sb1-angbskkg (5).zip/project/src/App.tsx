import React, { useState } from 'react';
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import { 
  Container,
  Paper,
  Typography,
  Grid,
  IconButton,
  Fab,
  Dialog,
  DialogTitle,
  DialogContent,
  AppBar,
  Toolbar,
  Hidden
} from '@material-ui/core';
import {
  Notifications as BellIcon,
  Assignment as ClipboardIcon,
  Warning as WarningIcon,
  BarChart as ChartIcon,
  Print as PrintIcon,
  Close as CloseIcon
} from '@material-ui/icons';
import Header from './components/Header';
import SosView from './components/SosView';
import FollowUpView from './components/FollowUpView';
import NTCView from './components/NTCView';
import DataSummary from './components/DataSummary';
import { dataService } from './services/data';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      minHeight: '100vh',
      backgroundColor: theme.palette.grey[100],
    },
    main: {
      padding: theme.spacing(4),
    },
    fab: {
      position: 'fixed',
      bottom: theme.spacing(3),
      right: theme.spacing(3),
    },
    summaryFab: {
      right: theme.spacing(12),
    },
    dialogContent: {
      padding: theme.spacing(3),
    },
    printSection: {
      display: 'none',
      '@media print': {
        display: 'block',
      },
    },
    nonPrintSection: {
      '@media print': {
        display: 'none',
      },
    },
  })
);

function App() {
  const classes = useStyles();
  const [activeView, setActiveView] = useState('SOS');
  const [showSummary, setShowSummary] = useState(false);

  const orgDetails = dataService.getOrgDetails();
  const meetings = dataService.getMeetings();
  const representatives = dataService.getRepresentatives();
  const mainReasons = dataService.getMainReasons();
  const followUpActions = dataService.getFollowUpActions();
  const rmActions = dataService.getRMActions();
  const customerSuppliers = dataService.getCustomerSuppliers();
  const riskMitigations = dataService.getRiskMitigations();
  const companySummary = dataService.getCompanySummary();
  const businessDescription = dataService.getBusinessDescription();
  const organizationDetails = dataService.getOrganizationDetails();
  const managementInfo = dataService.getManagementInfo();
  const industryOutlooks = dataService.getIndustryOutlooks();

  const navItems = [
    { name: 'SOS', icon: <BellIcon /> },
    { name: 'FollowUp', icon: <ClipboardIcon /> },
    { name: 'NTC', icon: <WarningIcon /> }
  ];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className={classes.root}>
      <Header 
        orgName={orgDetails.name}
        manager={orgDetails.manager}
        cin={orgDetails.cin}
        navItems={navItems}
        onNavClick={setActiveView}
        activeView={activeView}
      />

      <Container className={classes.main}>
        <Dialog 
          fullWidth 
          maxWidth="lg" 
          open={showSummary} 
          onClose={() => setShowSummary(false)}
        >
          <DialogTitle>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Typography variant="h6">Overall Summary</Typography>
              <IconButton onClick={() => setShowSummary(false)}>
                <CloseIcon />
              </IconButton>
            </div>
          </DialogTitle>
          <DialogContent className={classes.dialogContent}>
            <DataSummary
              meetings={meetings}
              representatives={representatives}
              mainReasons={mainReasons}
              followUpActions={followUpActions}
              rmActions={rmActions}
              customerSuppliers={customerSuppliers}
              riskMitigations={riskMitigations}
            />
          </DialogContent>
        </Dialog>

        <div className={classes.printSection}>
          <Typography variant="h4" gutterBottom>Summary of All Views</Typography>
          <DataSummary
            meetings={meetings}
            representatives={representatives}
            mainReasons={mainReasons}
            followUpActions={followUpActions}
            rmActions={rmActions}
            customerSuppliers={customerSuppliers}
            riskMitigations={riskMitigations}
          />
        </div>

        <div className={activeView === 'SOS' ? undefined : classes.printSection}>
          <Typography variant="h5" gutterBottom>SOS View</Typography>
          <SosView 
            companySummary={companySummary}
            meetings={meetings}
            representatives={representatives}
            mainReasons={mainReasons}
          />
        </div>

        <div className={activeView === 'FollowUp' ? undefined : classes.printSection}>
          <Typography variant="h5" gutterBottom>Follow Up View</Typography>
          <FollowUpView
            followUpActions={followUpActions}
            rmActions={rmActions}
          />
        </div>

        <div className={activeView === 'NTC' ? undefined : classes.printSection}>
          <Typography variant="h5" gutterBottom>NTC View</Typography>
          <NTCView
            businessDescription={businessDescription}
            customerSuppliers={customerSuppliers}
            organizationDetails={organizationDetails}
            riskMitigations={riskMitigations}
            managementInfo={managementInfo}
            industryOutlooks={industryOutlooks}
          />
        </div>
      </Container>

      <div className={classes.nonPrintSection}>
        <Fab
          color="primary"
          className={`${classes.fab} ${classes.summaryFab}`}
          onClick={() => setShowSummary(true)}
        >
          <ChartIcon />
        </Fab>
        <Fab
          color="primary"
          className={classes.fab}
          onClick={handlePrint}
        >
          <PrintIcon />
        </Fab>
      </div>
    </div>
  );
}

export default App;