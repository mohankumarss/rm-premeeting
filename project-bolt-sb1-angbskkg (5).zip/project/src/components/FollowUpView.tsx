import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Grid,
  Box
} from '@material-ui/core';
import { Calendar, User } from 'lucide-react';
import { motion } from 'framer-motion';

const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      marginBottom: theme.spacing(4),
    },
  },
  paper: {
    borderRadius: theme.shape.borderRadius,
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    overflow: 'hidden',
  },
  header: {
    padding: theme.spacing(3),
    borderBottom: `1px solid ${theme.palette.divider}`,
    backgroundColor: theme.palette.background.default,
  },
  tableContainer: {
    margin: 0,
  },
  chip: {
    borderRadius: theme.shape.borderRadius,
  },
  statusChip: {
    '&.Completed': {
      backgroundColor: '#dcfce7',
      color: '#166534',
    },
    '&.InProgress': {
      backgroundColor: '#fef9c3',
      color: '#854d0e',
    },
    '&.Pending': {
      backgroundColor: '#fee2e2',
      color: '#991b1b',
    },
    '&.Scheduled': {
      backgroundColor: '#dbeafe',
      color: '#1e40af',
    },
  },
  priorityChip: {
    '&.High': {
      backgroundColor: '#fee2e2',
      color: '#991b1b',
    },
    '&.Medium': {
      backgroundColor: '#fef9c3',
      color: '#854d0e',
    },
    '&.Low': {
      backgroundColor: '#dbeafe',
      color: '#1e40af',
    },
  },
  assigneeCell: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(1),
  },
  icon: {
    width: 16,
    height: 16,
  },
}));

interface FollowUpAction {
  date: string;
  action: string;
  status: string;
  priority: string;
  assignee: string;
}

interface RMAction {
  date: string;
  action: string;
  customer: string;
  status: string;
  nextSteps: string;
}

interface FollowUpViewProps {
  followUpActions: FollowUpAction[];
  rmActions: RMAction[];
}

const FollowUpView: React.FC<FollowUpViewProps> = ({ followUpActions, rmActions }) => {
  const classes = useStyles();

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={classes.root}
    >
      <Grid container spacing={4}>
        <Grid item xs={12}>
          <Paper className={classes.paper}>
            <Box className={classes.header}>
              <Typography variant="h6">Follow-up Actions</Typography>
            </Box>
            <TableContainer className={classes.tableContainer}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Date</TableCell>
                    <TableCell>Action</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Priority</TableCell>
                    <TableCell>Assignee</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {followUpActions.map((action, index) => (
                    <TableRow key={index} hover>
                      <TableCell>
                        <Box className={classes.assigneeCell}>
                          <Calendar className={classes.icon} />
                          {formatDate(action.date)}
                        </Box>
                      </TableCell>
                      <TableCell>{action.action}</TableCell>
                      <TableCell>
                        <Chip
                          label={action.status}
                          size="small"
                          className={`${classes.statusChip} ${action.status.replace(/\s+/g, '')}`}
                        />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={action.priority}
                          size="small"
                          className={`${classes.priorityChip} ${action.priority}`}
                        />
                      </TableCell>
                      <TableCell>
                        <Box className={classes.assigneeCell}>
                          <User className={classes.icon} />
                          {action.assignee}
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Paper className={classes.paper}>
            <Box className={classes.header}>
              <Typography variant="h6">RM Actions</Typography>
            </Box>
            <TableContainer className={classes.tableContainer}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Date</TableCell>
                    <TableCell>Action</TableCell>
                    <TableCell>Customer</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Next Steps</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rmActions.map((action, index) => (
                    <TableRow key={index} hover>
                      <TableCell>
                        <Box className={classes.assigneeCell}>
                          <Calendar className={classes.icon} />
                          {formatDate(action.date)}
                        </Box>
                      </TableCell>
                      <TableCell>{action.action}</TableCell>
                      <TableCell>{action.customer}</TableCell>
                      <TableCell>
                        <Chip
                          label={action.status}
                          size="small"
                          className={`${classes.statusChip} ${action.status.replace(/\s+/g, '')}`}
                        />
                      </TableCell>
                      <TableCell>{action.nextSteps}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>
    </motion.div>
  );
};

export default FollowUpView;