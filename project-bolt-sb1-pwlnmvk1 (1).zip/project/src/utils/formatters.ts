import { format, parseISO } from 'date-fns';

// Format duration in seconds to readable time format (mm:ss or hh:mm:ss)
export const formatDuration = (seconds: number): string => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;
  
  if (hours > 0) {
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
  }
  
  return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
};

// Format ISO date string to readable format
export const formatDate = (dateString: string): string => {
  try {
    const date = parseISO(dateString);
    return format(date, 'MMM d, yyyy h:mm a');
  } catch (error) {
    return dateString;
  }
};

// Get sentiment color based on sentiment value
export const getSentimentColor = (sentiment: string | undefined): string => {
  switch (sentiment) {
    case 'positive':
      return 'bg-green-100 text-green-800';
    case 'negative':
      return 'bg-red-100 text-red-800';
    case 'neutral':
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

// Get call type badge color
export const getCallTypeColor = (callType: string | undefined): string => {
  switch (callType) {
    case 'incoming':
      return 'bg-blue-100 text-blue-800';
    case 'outgoing':
      return 'bg-purple-100 text-purple-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

// Truncate text with ellipsis
export const truncateText = (text: string, maxLength: number): string => {
  return text.length > maxLength ? `${text.substring(0, maxLength)}...` : text;
};