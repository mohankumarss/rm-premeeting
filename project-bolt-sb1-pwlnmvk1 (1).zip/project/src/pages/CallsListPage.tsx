import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout/Layout';
import CallsTable from '../components/calls/CallsTable';
import { callsApi } from '../services/api';
import { CallRecord } from '../types';

const CallsListPage: React.FC = () => {
  const [calls, setCalls] = useState<CallRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCalls = async () => {
      try {
        setIsLoading(true);
        const response = await callsApi.getAllCalls();
        
        if (response.status === 200) {
          setCalls(response.data);
        } else {
          setError('Error fetching calls: ' + response.message);
        }
      } catch (err) {
        setError('An error occurred while fetching the calls data.');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchCalls();
  }, []);

  return (
    <Layout>
      <div className="py-6 animate-fade-in">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Calls</h1>
            <p className="mt-1 text-sm text-gray-500">
              A list of all call records in your account including their phone number, duration, end date, and topics.
            </p>
          </div>
          <div>
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors"
            >
              Export Data
            </button>
          </div>
        </div>

        <div className="mt-6">
          {error ? (
            <div className="rounded-md bg-red-50 p-4">
              <div className="flex">
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-red-800">Error Loading Data</h3>
                  <div className="mt-2 text-sm text-red-700">
                    <p>{error}</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <CallsTable calls={calls} isLoading={isLoading} />
          )}
        </div>
      </div>
    </Layout>
  );
};

export default CallsListPage;