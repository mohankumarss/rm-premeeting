export interface Message {
  timestamp: string;
  speaker: 'Agent' | 'Customer';
  type: string;
  content: string;
}

export interface CallRecord {
  id: string;
  phoneNumber: string;
  callDuration: number;
  callEndDate: string;
  topicsDiscussed: string[];
  notes?: string;
  sentiment?: 'positive' | 'neutral' | 'negative';
  callType?: 'incoming' | 'outgoing';
  agentName?: string;
  recordingUrl?: string;
  transcriptSummary?: string;
  conversation?: Message[];
  themes?: string[];
}

export interface ApiResponse<T> {
  data: T;
  status: number;
  message: string;
}