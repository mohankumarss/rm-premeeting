import { CallRecord, ApiResponse } from '../types';

const mockCalls: CallRecord[] = [
  {
    id: '1',
    phoneNumber: '+44 20 7123 4567',
    callDuration: 925,
    callEndDate: '2025-04-01T14:30:00Z',
    topicsDiscussed: ['Trade Finance', 'Business Current Account', 'International Payments', 'Online Banking'],
    notes: 'Client discussed European expansion plans and Brexit-related banking requirements. Reviewed current account services and international payment solutions. Scheduled follow-up meeting to discuss trade finance facilities. Client expressed interest in enhanced online banking features for better cash flow management.',
    sentiment: 'positive',
    callType: 'incoming',
    agentName: 'James Wilson',
    transcriptSummary: 'Comprehensive discussion about European expansion and banking solutions',
    conversation: [
      {
        timestamp: '00:00',
        speaker: 'Agent',
        type: 'Introduction',
        content: 'Good morning, James Wilson from Barclays Commercial Banking in London. How may I help you today?'
      },
      {
        timestamp: '00:15',
        speaker: 'Customer',
        type: 'Business Growth',
        content: 'Morning James, Richard Thompson from Thompson Manufacturing here. We\'re planning to expand our operations into the EU market, particularly Germany and France, and I\'d like to discuss our banking requirements.'
      },
      {
        timestamp: '00:45',
        speaker: 'Agent',
        type: 'Needs Assessment',
        content: 'Certainly, Richard. Could you tell me more about your expansion plans and the level of funding you\'re considering?'
      },
      {
        timestamp: '01:15',
        speaker: 'Customer',
        type: 'Business Details',
        content: 'We\'re looking to set up distribution centres in Frankfurt and Lyon. We\'re estimating we\'ll need around £3 million initially. Our projections show this could increase our turnover by 35% within 18 months.'
      },
      {
        timestamp: '02:00',
        speaker: 'Agent',
        type: 'Solution Discussion',
        content: 'Thank you for those details. Given your European expansion, we should look at our sterling and euro business current accounts, along with our trade finance solutions. Have you considered our foreign exchange risk management services?'
      },
      {
        timestamp: '02:30',
        speaker: 'Customer',
        type: 'Information Request',
        content: 'Not yet, no. What FX solutions can you offer?'
      },
      {
        timestamp: '03:00',
        speaker: 'Agent',
        type: 'Product Information',
        content: 'We offer forward contracts, FX options, and spot transactions through our dealing room. These can help protect against currency fluctuations between sterling and euros. Would you like me to explain these in more detail?'
      },
      {
        timestamp: '03:45',
        speaker: 'Customer',
        type: 'Interest Expression',
        content: 'Yes, particularly interested in forward contracts. With Brexit changes, we need to be extra careful about currency exposure.'
      },
      {
        timestamp: '04:30',
        speaker: 'Agent',
        type: 'Solution Details',
        content: 'Our forward contracts let you lock in exchange rates for up to 12 months. We also have our BARX platform for real-time FX trading and monitoring.'
      },
      {
        timestamp: '05:15',
        speaker: 'Customer',
        type: 'Digital Banking',
        content: 'That\'s helpful. What about online banking for managing our UK and European accounts?'
      },
      {
        timestamp: '06:00',
        speaker: 'Agent',
        type: 'Digital Solutions',
        content: 'Our Corporate Banking Online platform allows you to manage all your accounts, make SEPA payments, and use SWIFT for international transfers. Would you like to see a demonstration?'
      },
      {
        timestamp: '06:45',
        speaker: 'Customer',
        type: 'Cash Management',
        content: 'Yes, please. Also, what solutions do you have for optimising our working capital across the UK and EU?'
      },
      {
        timestamp: '07:30',
        speaker: 'Agent',
        type: 'Advisory',
        content: 'I\'d recommend our European Cash Management solution with notional pooling. This helps optimise liquidity across your sterling and euro accounts while reducing transaction costs.'
      },
      {
        timestamp: '08:15',
        speaker: 'Customer',
        type: 'Documentation',
        content: 'Could you send me detailed information about these services, including the lending terms and account charges?'
      },
      {
        timestamp: '09:00',
        speaker: 'Agent',
        type: 'Next Steps',
        content: 'Of course. I\'ll prepare a comprehensive proposal including all services we\'ve discussed. Would you be free for a meeting at our Canary Wharf office next week to review everything?'
      },
      {
        timestamp: '09:30',
        speaker: 'Customer',
        type: 'Meeting Schedule',
        content: 'Yes, that works. How about next Tuesday at 10 AM?'
      }
    ],
    themes: ['European Expansion', 'Trade Finance', 'FX Management', 'Cash Management']
  },
  {
    id: '2',
    phoneNumber: '+44 20 7987 6543',
    callDuration: 542,
    callEndDate: '2025-04-01T16:45:00Z',
    topicsDiscussed: ['Account Management', 'Complaints', 'Service Quality'],
    notes: 'Customer expressed concerns about service quality. Offered relationship review meeting.',
    sentiment: 'negative',
    callType: 'incoming',
    agentName: 'Emma Thompson',
    transcriptSummary: 'Service quality discussion and resolution planning'
  },
  {
    id: '3',
    phoneNumber: '+44 20 7567 8901',
    callDuration: 187,
    callEndDate: '2025-04-02T09:15:00Z',
    topicsDiscussed: ['New Services', 'Pricing'],
    notes: 'Potential new customer inquiring about commercial banking services.',
    sentiment: 'positive',
    callType: 'incoming',
    agentName: 'David Parker',
    transcriptSummary: 'New customer service inquiry and pricing discussion'
  },
  {
    id: '4',
    phoneNumber: '+44 20 7234 5678',
    callDuration: 412,
    callEndDate: '2025-04-02T11:30:00Z',
    topicsDiscussed: ['Technical Support', 'Online Banking', 'Security'],
    notes: 'Resolved online banking access issues and reviewed security protocols.',
    sentiment: 'positive',
    callType: 'outgoing',
    agentName: 'Sarah Mitchell',
    transcriptSummary: 'Technical support and security review'
  },
  {
    id: '5',
    phoneNumber: '+44 20 7345 6789',
    callDuration: 278,
    callEndDate: '2025-04-03T13:45:00Z',
    topicsDiscussed: ['Account Management', 'Direct Debit', 'Standing Orders'],
    notes: 'Updated payment mandates and reviewed account services.',
    sentiment: 'neutral',
    callType: 'incoming',
    agentName: 'Robert Taylor',
    transcriptSummary: 'Payment mandate updates and account service review'
  },
  {
    id: '6',
    phoneNumber: '+44 20 7456 7890',
    callDuration: 631,
    callEndDate: '2025-04-03T15:20:00Z',
    topicsDiscussed: ['Technical Support', 'Mobile Banking', 'App Features'],
    notes: 'Complex mobile banking issue. Escalated to IT support.',
    sentiment: 'negative',
    callType: 'incoming',
    agentName: 'Emily Watson',
    transcriptSummary: 'Mobile banking technical support escalation'
  },
  {
    id: '7',
    phoneNumber: '+44 20 7678 9012',
    callDuration: 195,
    callEndDate: '2025-04-04T10:10:00Z',
    topicsDiscussed: ['Feedback', 'Service Quality'],
    notes: 'Customer provided positive feedback about recent service improvements.',
    sentiment: 'positive',
    callType: 'outgoing',
    agentName: 'James Wilson',
    transcriptSummary: 'Service improvement feedback collection'
  },
  {
    id: '8',
    phoneNumber: '+44 20 7789 0123',
    callDuration: 347,
    callEndDate: '2025-04-04T14:50:00Z',
    topicsDiscussed: ['Account Review', 'Service Upgrade'],
    notes: 'Annual account review and service optimization discussion.',
    sentiment: 'positive',
    callType: 'incoming',
    agentName: 'Sarah Mitchell',
    transcriptSummary: 'Annual account review and service optimization'
  }
];

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const callsApi = {
  async getAllCalls(): Promise<ApiResponse<CallRecord[]>> {
    await delay(800);
    return {
      data: mockCalls,
      status: 200,
      message: 'Calls retrieved successfully'
    };
  },

  async getCallById(id: string): Promise<ApiResponse<CallRecord>> {
    await delay(600);
    const call = mockCalls.find(call => call.id === id);
    
    if (!call) {
      return {
        data: {} as CallRecord,
        status: 404,
        message: 'Call not found'
      };
    }
    
    return {
      data: call,
      status: 200,
      message: 'Call retrieved successfully'
    };
  }
};