import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  path: string;
  active?: boolean;
}

interface BreadcrumbsProps {
  items?: BreadcrumbItem[];
  callId?: string;
}

const Breadcrumbs: React.FC<BreadcrumbsProps> = ({ items, callId }) => {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter(x => x);
  
  // Generate breadcrumbs from current path if not provided
  const breadcrumbs: BreadcrumbItem[] = items || [
    { label: 'Home', path: '/' },
    ...(pathnames.map((value, index) => {
      const path = `/${pathnames.slice(0, index + 1).join('/')}`;
      let label = value;
      
      // Format "calls" to "Calls"
      if (value === 'calls') {
        label = 'Calls';
      }
      
      // Format call ID
      if (value === callId) {
        label = `Call #${callId}`;
      }
      
      return {
        label,
        path,
        active: index === pathnames.length - 1
      };
    }))
  ];

  return (
    <nav className="flex py-4" aria-label="Breadcrumb">
      <ol className="flex items-center space-x-1 md:space-x-2">
        {breadcrumbs.map((breadcrumb, index) => (
          <li key={breadcrumb.path}>
            <div className="flex items-center">
              {index > 0 && (
                <ChevronRight className="flex-shrink-0 h-4 w-4 text-gray-400 mx-1" aria-hidden="true" />
              )}
              {breadcrumb.active ? (
                <span className="text-sm font-medium text-gray-500" aria-current="page">
                  {breadcrumb.label}
                </span>
              ) : (
                <Link 
                  to={breadcrumb.path} 
                  className="text-sm font-medium text-primary-600 hover:text-primary-700 transition-colors"
                >
                  {index === 0 ? (
                    <div className="flex items-center">
                      <Home className="h-4 w-4 mr-1" />
                      <span>{breadcrumb.label}</span>
                    </div>
                  ) : (
                    breadcrumb.label
                  )}
                </Link>
              )}
            </div>
          </li>
        ))}
      </ol>
    </nav>
  );
};

export default Breadcrumbs;