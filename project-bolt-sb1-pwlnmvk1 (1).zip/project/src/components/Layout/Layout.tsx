import React from 'react';
import Header from './Header';
import Footer from './Footer';
import Breadcrumbs from './Breadcrumbs';

interface LayoutProps {
  children: React.ReactNode;
  showBreadcrumbs?: boolean;
  callId?: string;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  showBreadcrumbs = true,
  callId
}) => {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {showBreadcrumbs && <Breadcrumbs callId={callId} />}
          {children}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Layout;