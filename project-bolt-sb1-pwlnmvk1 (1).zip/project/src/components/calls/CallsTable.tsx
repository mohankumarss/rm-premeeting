import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CallRecord } from '../../types';
import { formatDuration, formatDate, getSentimentColor } from '../../utils/formatters';
import { Phone, Clock, Calendar, Tag, ArrowUp, ArrowDown } from 'lucide-react';

interface CallsTableProps {
  calls: CallRecord[];
  isLoading: boolean;
}

type SortField = 'id' | 'phoneNumber' | 'callDuration' | 'callEndDate';
type SortDirection = 'asc' | 'desc';

const CallsTable: React.FC<CallsTableProps> = ({ calls, isLoading }) => {
  const navigate = useNavigate();
  const [sortField, setSortField] = useState<SortField>('callEndDate');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedCalls = [...calls].sort((a, b) => {
    let compareA: string | number = '';
    let compareB: string | number = '';

    switch (sortField) {
      case 'id':
        compareA = a.id;
        compareB = b.id;
        break;
      case 'phoneNumber':
        compareA = a.phoneNumber;
        compareB = b.phoneNumber;
        break;
      case 'callDuration':
        compareA = a.callDuration;
        compareB = b.callDuration;
        break;
      case 'callEndDate':
        compareA = new Date(a.callEndDate).getTime();
        compareB = new Date(b.callEndDate).getTime();
        break;
      default:
        compareA = new Date(a.callEndDate).getTime();
        compareB = new Date(b.callEndDate).getTime();
    }

    if (typeof compareA === 'string' && typeof compareB === 'string') {
      return sortDirection === 'asc'
        ? compareA.localeCompare(compareB)
        : compareB.localeCompare(compareA);
    } else {
      return sortDirection === 'asc'
        ? Number(compareA) - Number(compareB)
        : Number(compareB) - Number(compareA);
    }
  });

  const handleRowClick = (id: string) => {
    navigate(`/calls/${id}`);
  };

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) return null;
    
    return sortDirection === 'asc' ? (
      <ArrowUp className="h-4 w-4 ml-1 inline" />
    ) : (
      <ArrowDown className="h-4 w-4 ml-1 inline" />
    );
  };

  if (isLoading) {
    return (
      <div className="animate-pulse bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <div className="h-6 bg-gray-200 rounded w-1/4"></div>
        </div>
        <div className="border-t border-gray-200">
          {[...Array(5)].map((_, index) => (
            <div 
              key={index} 
              className="px-4 py-5 sm:p-6 flex flex-col sm:flex-row justify-between gap-4"
            >
              <div className="h-4 bg-gray-200 rounded w-1/12"></div>
              <div className="h-4 bg-gray-200 rounded w-2/12"></div>
              <div className="h-4 bg-gray-200 rounded w-1/12"></div>
              <div className="h-4 bg-gray-200 rounded w-2/12"></div>
              <div className="h-4 bg-gray-200 rounded w-4/12"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('id')}
              >
                <div className="flex items-center">
                  ID {renderSortIcon('id')}
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('phoneNumber')}
              >
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-1" />
                  Phone Number {renderSortIcon('phoneNumber')}
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('callDuration')}
              >
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  Duration {renderSortIcon('callDuration')}
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('callEndDate')}
              >
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  End Date {renderSortIcon('callEndDate')}
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                <div className="flex items-center">
                  <Tag className="h-4 w-4 mr-1" />
                  Topics
                </div>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sortedCalls.map((call) => (
              <tr 
                key={call.id} 
                onClick={() => handleRowClick(call.id)}
                className="cursor-pointer hover:bg-gray-50 transition-colors"
              >
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {call.id}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {call.phoneNumber}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {formatDuration(call.callDuration)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {formatDate(call.callEndDate)}
                </td>
                <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                  <div className="flex flex-wrap gap-2">
                    {call.topicsDiscussed.map((topic, index) => (
                      <span 
                        key={index} 
                        className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${getSentimentColor(call.sentiment)}`}
                      >
                        {topic}
                      </span>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CallsTable;