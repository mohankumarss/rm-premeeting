import React from 'react';
import { CallRecord } from '../../types';
import { formatDuration, formatDate, getSentimentColor, getCallTypeColor } from '../../utils/formatters';
import { Phone, Clock, Calendar, FileText, User, MessageCircle, ArrowUpRight, ArrowDownLeft } from 'lucide-react';

interface CallDetailCardProps {
  call: CallRecord;
  isLoading: boolean;
}

const CallDetailCard: React.FC<CallDetailCardProps> = ({ call, isLoading }) => {
  if (isLoading) {
    return (
      <div className="animate-pulse bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <div className="h-6 bg-gray-200 rounded w-1/4"></div>
          <div className="mt-2 h-4 bg-gray-200 rounded w-1/2"></div>
        </div>
        <div className="border-t border-gray-200">
          {[...Array(5)].map((_, index) => (
            <div key={index} className="px-4 py-5 sm:p-6">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="mt-2 h-4 bg-gray-200 rounded w-5/6"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg animate-fade-in">
      <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Call Details
            </h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              Complete information about call #{call.id}
            </p>
          </div>
          <div className="flex items-center">
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getCallTypeColor(call.callType)}`}>
              {call.callType === 'incoming' ? (
                <>
                  <ArrowDownLeft className="h-4 w-4 mr-1" />
                  Incoming
                </>
              ) : (
                <>
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                  Outgoing
                </>
              )}
            </span>
          </div>
        </div>
      </div>
      
      <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
        <dl className="sm:divide-y sm:divide-gray-200">
          <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500 flex items-center">
              <Phone className="h-4 w-4 mr-2" /> Phone Number
            </dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {call.phoneNumber}
            </dd>
          </div>
          
          <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500 flex items-center">
              <User className="h-4 w-4 mr-2" /> Agent
            </dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {call.agentName || 'Unknown'}
            </dd>
          </div>
          
          <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500 flex items-center">
              <Clock className="h-4 w-4 mr-2" /> Call Duration
            </dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {formatDuration(call.callDuration)}
            </dd>
          </div>
          
          <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500 flex items-center">
              <Calendar className="h-4 w-4 mr-2" /> Call End Date
            </dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {formatDate(call.callEndDate)}
            </dd>
          </div>
          
          <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500 flex items-center">
              <MessageCircle className="h-4 w-4 mr-2" /> Sentiment
            </dt>
            <dd className="mt-1 text-sm sm:mt-0 sm:col-span-2">
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getSentimentColor(call.sentiment)}`}>
                {call.sentiment ? call.sentiment.charAt(0).toUpperCase() + call.sentiment.slice(1) : 'Unknown'}
              </span>
            </dd>
          </div>
          
          <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Topics Discussed</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              <div className="flex flex-wrap gap-2">
                {call.topicsDiscussed.map((topic, index) => (
                  <span 
                    key={index} 
                    className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                  >
                    {topic}
                  </span>
                ))}
              </div>
            </dd>
          </div>
          
          <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500 flex items-center">
              <FileText className="h-4 w-4 mr-2" /> Notes
            </dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {call.notes || 'No notes available for this call.'}
            </dd>
          </div>
          
          <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Transcript Summary</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {call.transcriptSummary || 'Transcript summary not available.'}
            </dd>
          </div>
          
          {call.recordingUrl && (
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Recording</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                <div className="flex items-center">
                  <button 
                    type="button"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors"
                  >
                    Play Recording
                  </button>
                </div>
              </dd>
            </div>
          )}
        </dl>
      </div>
    </div>
  );
};

export default CallDetailCard;