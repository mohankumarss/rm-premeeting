import React, { useState } from 'react';
import Header from './components/Header';
import SosView from './components/SosView';
import FollowUpView from './components/FollowUpView';
import NTCView from './components/NTCView';
import DataSummary from './components/DataSummary';
import { Bell, ClipboardList, FileWarning, BarChart2 } from 'lucide-react';
import { dataService } from './services/data';

function App() {
  const [activeView, setActiveView] = useState('SOS');
  const [showSummary, setShowSummary] = useState(false);

  const orgDetails = dataService.getOrgDetails();
  const meetings = dataService.getMeetings();
  const representatives = dataService.getRepresentatives();
  const mainReasons = dataService.getMainReasons();
  const followUpActions = dataService.getFollowUpActions();
  const rmActions = dataService.getRMActions();
  const customerSuppliers = dataService.getCustomerSuppliers();
  const riskMitigations = dataService.getRiskMitigations();
  const companySummary = dataService.getCompanySummary();
  const businessDescription = dataService.getBusinessDescription();
  const organizationDetails = dataService.getOrganizationDetails();
  const managementInfo = dataService.getManagementInfo();
  const industryOutlooks = dataService.getIndustryOutlooks();

  const navItems = [
    { name: 'SOS', icon: <Bell className="w-4 h-4" /> },
    { name: 'FollowUp', icon: <ClipboardList className="w-4 h-4" /> },
    { name: 'NTC', icon: <FileWarning className="w-4 h-4" /> }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        orgName={orgDetails.name}
        manager={orgDetails.manager}
        cin={orgDetails.cin}
        navItems={navItems}
        onNavClick={setActiveView}
        activeView={activeView}
      />
      <main className="container mx-auto px-4 py-8">
        {/* Summary View Modal */}
        {showSummary && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-2xl font-bold">Overall Summary</h2>
                <button 
                  onClick={() => setShowSummary(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="p-6">
                <DataSummary
                  meetings={meetings}
                  representatives={representatives}
                  mainReasons={mainReasons}
                  followUpActions={followUpActions}
                  rmActions={rmActions}
                  customerSuppliers={customerSuppliers}
                  riskMitigations={riskMitigations}
                />
              </div>
            </div>
          </div>
        )}

        <div className="hidden print:block">
          <h2 className="text-2xl font-bold mb-8">Summary of All Views</h2>
          <DataSummary
            meetings={meetings}
            representatives={representatives}
            mainReasons={mainReasons}
            followUpActions={followUpActions}
            rmActions={rmActions}
            customerSuppliers={customerSuppliers}
            riskMitigations={riskMitigations}
          />
        </div>
        <div className={`${activeView === 'SOS' ? '' : 'hidden print:block'}`}>
          <h3 className="text-xl font-semibold mb-6 print:mt-8">SOS View</h3>
          <SosView 
            companySummary={companySummary} 
            meetings={meetings} 
            representatives={representatives}
            mainReasons={mainReasons}
          />
        </div>
        <div className={`${activeView === 'FollowUp' ? '' : 'hidden print:block'}`}>
          <h3 className="text-xl font-semibold mb-6 print:mt-8">Follow Up View</h3>
          <FollowUpView
            followUpActions={followUpActions}
            rmActions={rmActions}
          />
        </div>
        <div className={`${activeView === 'NTC' ? '' : 'hidden print:block'}`}>
          <h3 className="text-xl font-semibold mb-6 print:mt-8">NTC View</h3>
          <NTCView
            businessDescription={businessDescription}
            customerSuppliers={customerSuppliers}
            organizationDetails={organizationDetails}
            riskMitigations={riskMitigations}
            managementInfo={managementInfo}
            industryOutlooks={industryOutlooks}
          />
        </div>
      </main>

      {/* Floating Summary Button */}
      <button
        onClick={() => setShowSummary(true)}
        className="fixed bottom-6 right-24 p-3 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 transition-colors print:hidden"
        aria-label="Show Summary"
      >
        <BarChart2 className="w-6 h-6" />
      </button>
    </div>
  );
}

export default App;