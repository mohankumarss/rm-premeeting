import React, { useState } from 'react';
import Header from './components/Header';
import SosView from './components/SosView';
import FollowUpView from './components/FollowUpView';
import NTCView from './components/NTCView';
import DataSummary from './components/DataSummary';
import { Building2, Bell, ClipboardList, FileWarning, BarChart2 } from 'lucide-react';

function App() {
  const [activeView, setActiveView] = useState('SOS');
  const [showSummary, setShowSummary] = useState(false);

  const orgDetails = {
    name: "Global Solutions Inc.",
    manager: "John Smith",
    cin: "L12345AB2024PLC098765"
  };

  const meetings = [
    {
      date: "2024-03-15",
      summary: "Quarterly business review",
      type: "Strategic"
    },
    {
      date: "2024-03-10",
      summary: "Technical implementation meeting",
      type: "Technical"
    },
    {
      date: "2024-03-05",
      summary: "Sales pipeline review",
      type: "Sales"
    }
  ];

  const representatives = [
    {
      name: "Sarah Johnson",
      role: "Account Executive",
      email: "sarah.j@example.com",
      phone: "+1-555-0123"
    },
    {
      name: "Michael Chen",
      role: "Technical Lead",
      email: "michael.c@example.com",
      phone: "+1-555-0124"
    }
  ];

  const mainReasons = [
    {
      title: "Business Growth",
      reasons: "Expansion into new markets",
      meetingType: "Strategic",
      representative: "Sarah Johnson",
      activityId: "BG-001"
    },
    {
      title: "Technical Integration",
      reasons: "System upgrade planning",
      meetingType: "Technical",
      representative: "Michael Chen",
      activityId: "TI-001"
    }
  ];

  const followUpActions = [
    {
      date: "2024-03-20",
      action: "Market analysis report",
      status: "In Progress",
      priority: "High",
      assignee: "Sarah Johnson"
    },
    {
      date: "2024-03-25",
      action: "Technical specification review",
      status: "Pending",
      priority: "Medium",
      assignee: "Michael Chen"
    },
    {
      date: "2024-03-15",
      action: "Client presentation",
      status: "Completed",
      priority: "High",
      assignee: "Sarah Johnson"
    }
  ];

  const rmActions = [
    {
      date: "2024-03-22",
      action: "Follow-up meeting",
      customer: "Global Solutions Inc.",
      status: "Scheduled",
      nextSteps: "Prepare agenda"
    },
    {
      date: "2024-03-18",
      action: "Contract review",
      customer: "Global Solutions Inc.",
      status: "Completed",
      nextSteps: "Send final draft"
    }
  ];

  const customerSuppliers = [
    {
      name: "TechCorp",
      type: "Customer",
      relationship: "Strategic",
      creditTerms: "Net 30",
      annualValue: "$500K",
      riskLevel: "Low"
    },
    {
      name: "SupplyTech",
      type: "Supplier",
      relationship: "Preferred",
      creditTerms: "Net 45",
      annualValue: "$300K",
      riskLevel: "Medium"
    }
  ];

  const riskMitigations = [
    {
      riskArea: "Market",
      description: "Competition increase",
      impact: "High",
      likelihood: "Medium",
      mitigationStrategy: "Product differentiation",
      status: "In Progress"
    },
    {
      riskArea: "Technical",
      description: "System integration",
      impact: "Medium",
      likelihood: "Low",
      mitigationStrategy: "Enhanced testing",
      status: "Ongoing"
    },
    {
      riskArea: "Financial",
      description: "Currency fluctuation",
      impact: "High",
      likelihood: "High",
      mitigationStrategy: "Hedging strategy",
      status: "Planned"
    }
  ];

  const companySummary = {
    description: "Leading technology solutions provider",
    industry: "Technology",
    founded: "2010",
    headquarters: "San Francisco",
    employees: "500+",
    revenue: "$50M+"
  };

  const businessDescription = {
    overview: "Global technology solutions provider",
    businessModel: "B2B SaaS",
    marketPosition: "Market Leader",
    competitiveAdvantage: "Innovative Technology",
    growthStrategy: "Market Expansion"
  };

  const organizationDetails = [
    {
      category: "Legal Structure",
      value: "Corporation",
      lastUpdated: "2024-01-01"
    },
    {
      category: "Regulatory Compliance",
      value: "ISO 27001",
      lastUpdated: "2024-02-01"
    }
  ];

  const managementInfo = [
    {
      name: "John Smith",
      position: "CEO",
      experience: "15+ years",
      expertise: "Strategy",
      achievements: "Company growth 200%"
    }
  ];

  const industryOutlooks = [
    {
      aspect: "Market Growth",
      details: {
        growth: "15% YoY",
        challenges: "Competitive market"
      }
    }
  ];

  const navItems = [
    { name: 'SOS', icon: <Bell className="w-4 h-4" /> },
    { name: 'FollowUp', icon: <ClipboardList className="w-4 h-4" /> },
    { name: 'NTC', icon: <FileWarning className="w-4 h-4" /> }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        orgName={orgDetails.name}
        manager={orgDetails.manager}
        cin={orgDetails.cin}
        navItems={navItems}
        onNavClick={setActiveView}
        activeView={activeView}
      />
      <main className="container mx-auto px-4 py-8">
        {/* Summary View Modal */}
        {showSummary && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-2xl font-bold">Overall Summary</h2>
                <button 
                  onClick={() => setShowSummary(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="p-6">
                <DataSummary
                  meetings={meetings}
                  representatives={representatives}
                  mainReasons={mainReasons}
                  followUpActions={followUpActions}
                  rmActions={rmActions}
                  customerSuppliers={customerSuppliers}
                  riskMitigations={riskMitigations}
                />
              </div>
            </div>
          </div>
        )}

        <div className="hidden print:block">
          <h2 className="text-2xl font-bold mb-8">Summary of All Views</h2>
          <DataSummary
            meetings={meetings}
            representatives={representatives}
            mainReasons={mainReasons}
            followUpActions={followUpActions}
            rmActions={rmActions}
            customerSuppliers={customerSuppliers}
            riskMitigations={riskMitigations}
          />
        </div>
        <div className={`${activeView === 'SOS' ? '' : 'hidden print:block'}`}>
          <h3 className="text-xl font-semibold mb-6 print:mt-8">SOS View</h3>
          <SosView 
            companySummary={companySummary} 
            meetings={meetings} 
            representatives={representatives}
            mainReasons={mainReasons}
          />
        </div>
        <div className={`${activeView === 'FollowUp' ? '' : 'hidden print:block'}`}>
          <h3 className="text-xl font-semibold mb-6 print:mt-8">Follow Up View</h3>
          <FollowUpView
            followUpActions={followUpActions}
            rmActions={rmActions}
          />
        </div>
        <div className={`${activeView === 'NTC' ? '' : 'hidden print:block'}`}>
          <h3 className="text-xl font-semibold mb-6 print:mt-8">NTC View</h3>
          <NTCView
            businessDescription={businessDescription}
            customerSuppliers={customerSuppliers}
            organizationDetails={organizationDetails}
            riskMitigations={riskMitigations}
            managementInfo={managementInfo}
            industryOutlooks={industryOutlooks}
          />
        </div>
      </main>

      {/* Floating Summary Button */}
      <button
        onClick={() => setShowSummary(true)}
        className="fixed bottom-6 right-24 p-3 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 transition-colors print:hidden"
        aria-label="Show Summary"
      >
        <BarChart2 className="w-6 h-6" />
      </button>
    </div>
  );
}

export default App;