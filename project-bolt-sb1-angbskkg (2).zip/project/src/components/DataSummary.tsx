import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { motion } from 'framer-motion';

interface DataSummaryProps {
  meetings: any[];
  representatives: any[];
  mainReasons: any[];
  followUpActions: any[];
  rmActions: any[];
  customerSuppliers: any[];
  riskMitigations: any[];
}

const COLORS = ['#0284c7', '#0ea5e9', '#38bdf8', '#7dd3fc', '#bae6fd'];

const DataSummary: React.FC<DataSummaryProps> = ({
  meetings,
  representatives,
  mainReasons,
  followUpActions,
  rmActions,
  customerSuppliers,
  riskMitigations,
}) => {
  // Prepare data for meeting types chart
  const meetingTypeData = meetings.reduce((acc: any, meeting) => {
    const existingType = acc.find((item: any) => item.name === meeting.type);
    if (existingType) {
      existingType.value++;
    } else {
      acc.push({ name: meeting.type, value: 1 });
    }
    return acc;
  }, []);

  // Prepare data for risk analysis
  const riskData = riskMitigations.map(risk => ({
    name: risk.riskArea,
    impact: risk.impact === 'High' ? 3 : risk.impact === 'Medium' ? 2 : 1,
    likelihood: risk.likelihood === 'High' ? 3 : risk.likelihood === 'Medium' ? 2 : 1,
  }));

  // Prepare data for action status
  const actionStatusData = [
    ...followUpActions,
    ...rmActions
  ].reduce((acc: any, action) => {
    const existingStatus = acc.find((item: any) => item.name === action.status);
    if (existingStatus) {
      existingStatus.value++;
    } else {
      acc.push({ name: action.status, value: 1 });
    }
    return acc;
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-8 print:space-y-12"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Meeting Types Distribution */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold mb-4">Meeting Types Distribution</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={meetingTypeData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {meetingTypeData.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Risk Analysis Matrix */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold mb-4">Risk Analysis</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={riskData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="impact" fill="#0284c7" name="Impact" />
                <Bar dataKey="likelihood" fill="#38bdf8" name="Likelihood" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Action Status Distribution */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold mb-4">Action Status Distribution</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={actionStatusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {actionStatusData.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Key Metrics Summary */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold mb-4">Key Metrics</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-blue-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Total Representatives</p>
              <p className="text-2xl font-bold text-blue-600">{representatives.length}</p>
            </div>
            <div className="bg-blue-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Total Meetings</p>
              <p className="text-2xl font-bold text-blue-600">{meetings.length}</p>
            </div>
            <div className="bg-blue-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Active Follow-ups</p>
              <p className="text-2xl font-bold text-blue-600">
                {followUpActions.filter(action => action.status === 'In Progress').length}
              </p>
            </div>
            <div className="bg-blue-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Business Partners</p>
              <p className="text-2xl font-bold text-blue-600">{customerSuppliers.length}</p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default DataSummary;