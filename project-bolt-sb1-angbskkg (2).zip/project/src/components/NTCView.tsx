import React from 'react';
import { Building2, Users, TrendingUp, AlertTriangle, LineChart, BarChart, PieChart, TrendingUp as ArrowTrendingUp } from 'lucide-react';

interface BusinessDescription {
  overview: string;
  businessModel: string;
  marketPosition: string;
  competitiveAdvantage: string;
  growthStrategy: string;
}

interface CustomerSupplier {
  name: string;
  type: 'Customer' | 'Supplier';
  relationship: string;
  creditTerms: string;
  annualValue: string;
  riskLevel: string;
}

interface OrganizationDetail {
  category: string;
  value: string;
  lastUpdated: string;
}

interface RiskMitigation {
  riskArea: string;
  description: string;
  impact: 'High' | 'Medium' | 'Low';
  likelihood: 'High' | 'Medium' | 'Low';
  mitigationStrategy: string;
  status: string;
}

interface ManagementInfo {
  name: string;
  position: string;
  experience: string;
  expertise: string;
  achievements: string;
}

interface IndustryOutlookDetails {
  revenue?: string;
  growth?: string;
  keyDrivers?: string;
  challenges?: string;
  marketPosition?: string;
  competitors?: string;
  competitiveEdge?: string;
  marketShare?: string;
  shortTerm?: string;
  mediumTerm?: string;
  longTerm?: string;
  risks?: string;
  opportunities?: string;
}

interface IndustryOutlook {
  aspect: string;
  details: IndustryOutlookDetails;
}

interface NTCViewProps {
  businessDescription: BusinessDescription;
  customerSuppliers: CustomerSupplier[];
  organizationDetails: OrganizationDetail[];
  riskMitigations: RiskMitigation[];
  managementInfo: ManagementInfo[];
  industryOutlooks: IndustryOutlook[];
}

const NTCView: React.FC<NTCViewProps> = ({
  businessDescription,
  customerSuppliers,
  organizationDetails,
  riskMitigations,
  managementInfo,
  industryOutlooks
}) => {
  const getOutlookIcon = (aspect: string) => {
    switch (aspect) {
      case 'Latest Industry Performance':
        return <BarChart className="h-5 w-5 text-blue-600" />;
      case 'Market Share/Competition':
        return <PieChart className="h-5 w-5 text-blue-600" />;
      case 'Outlook & Strategy':
        return <ArrowTrendingUp className="h-5 w-5 text-blue-600" />;
      default:
        return <TrendingUp className="h-5 w-5 text-blue-600" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Business Description */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Building2 className="h-6 w-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-900">Business Description</h2>
        </div>
        <div className="space-y-4">
          <p className="text-gray-700">{businessDescription.overview}</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Business Model</h3>
              <p className="text-gray-600">{businessDescription.businessModel}</p>
            </div>
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Market Position</h3>
              <p className="text-gray-600">{businessDescription.marketPosition}</p>
            </div>
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Competitive Advantage</h3>
              <p className="text-gray-600">{businessDescription.competitiveAdvantage}</p>
            </div>
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Growth Strategy</h3>
              <p className="text-gray-600">{businessDescription.growthStrategy}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Customer/Supplier Details Table */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <Users className="h-5 w-5 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">Customer/Supplier Details</h2>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Relationship</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Credit Terms</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Annual Value</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Risk Level</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {customerSuppliers.map((entity, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{entity.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{entity.type}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{entity.relationship}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{entity.creditTerms}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{entity.annualValue}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      entity.riskLevel === 'High' ? 'bg-red-100 text-red-800' :
                      entity.riskLevel === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {entity.riskLevel}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Organization Details */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Building2 className="h-5 w-5 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-900">Organization Details</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {organizationDetails.map((detail, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium text-gray-500">{detail.category}</h3>
              <p className="mt-2 text-lg font-semibold text-gray-900">{detail.value}</p>
              <p className="mt-1 text-xs text-gray-500">Last updated: {detail.lastUpdated}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Risk and Mitigation Analysis Table */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">Risk and Mitigation Analysis</h2>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Risk Area</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Impact</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Likelihood</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mitigation Strategy</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {riskMitigations.map((risk, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{risk.riskArea}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{risk.description}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      risk.impact === 'High' ? 'bg-red-100 text-red-800' :
                      risk.impact === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {risk.impact}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      risk.likelihood === 'High' ? 'bg-red-100 text-red-800' :
                      risk.likelihood === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {risk.likelihood}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{risk.mitigationStrategy}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      risk.status === 'Completed' ? 'bg-green-100 text-green-800' :
                      risk.status === 'In Progress' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {risk.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Management Information */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Users className="h-5 w-5 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-900">Management Information</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {managementInfo.map((manager, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium text-gray-900">{manager.name}</h3>
              <p className="text-sm text-blue-600 mb-2">{manager.position}</p>
              <div className="space-y-2 text-sm text-gray-600">
                <p><strong>Experience:</strong> {manager.experience}</p>
                <p><strong>Expertise:</strong> {manager.expertise}</p>
                <p><strong>Key Achievements:</strong> {manager.achievements}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Industry Outlook */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center space-x-2 mb-6">
          <TrendingUp className="h-5 w-5 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-900">Industry Outlook</h2>
        </div>
        <div className="space-y-6">
          {industryOutlooks.map((outlook, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-6">
              <div className="flex items-center space-x-2 mb-4">
                {getOutlookIcon(outlook.aspect)}
                <h3 className="text-lg font-medium text-gray-900">{outlook.aspect}</h3>
              </div>
              {outlook.aspect === 'Latest Industry Performance' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Market Size</p>
                    <p className="text-gray-900">{outlook.details.revenue}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Growth</p>
                    <p className="text-gray-900">{outlook.details.growth}</p>
                  </div>
                  <div className="md:col-span-2">
                    <p className="text-sm font-medium text-gray-500">Key Drivers</p>
                    <p className="text-gray-900">{outlook.details.keyDrivers}</p>
                  </div>
                  <div className="md:col-span-2">
                    <p className="text-sm font-medium text-gray-500">Challenges</p>
                    <p className="text-gray-900">{outlook.details.challenges}</p>
                  </div>
                </div>
              )}
              {outlook.aspect === 'Market Share/Competition' && (
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Market Position</p>
                    <p className="text-gray-900">{outlook.details.marketPosition}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Competitors</p>
                    <p className="text-gray-900">{outlook.details.competitors}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Competitive Edge</p>
                    <p className="text-gray-900">{outlook.details.competitiveEdge}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Market Share</p>
                    <p className="text-gray-900">{outlook.details.marketShare}</p>
                  </div>
                </div>
              )}
              {outlook.aspect === 'Outlook & Strategy' && (
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Short-term Strategy</p>
                    <p className="text-gray-900">{outlook.details.shortTerm}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Medium-term Strategy</p>
                    <p className="text-gray-900">{outlook.details.mediumTerm}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Long-term Vision</p>
                    <p className="text-gray-900">{outlook.details.longTerm}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Risks</p>
                    <p className="text-gray-900">{outlook.details.risks}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Opportunities</p>
                    <p className="text-gray-900">{outlook.details.opportunities}</p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NTCView;