import React, { useState } from 'react';
import { Building2, Menu, X } from 'lucide-react';

interface NavItem {
  name: string;
  icon: React.ReactNode;
}

interface HeaderProps {
  orgName: string;
  manager: string;
  cin: string;
  navItems: NavItem[];
  onNavClick: (view: string) => void;
  activeView: string;
}

const Header: React.FC<HeaderProps> = ({ 
  orgName, 
  manager, 
  cin, 
  navItems,
  onNavClick,
  activeView
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleNavClick = (name: string) => {
    onNavClick(name);
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Organization Details */}
          <div className="flex items-center space-x-4">
            <Building2 className="h-6 w-6 text-blue-600" />
            <div>
              <h1 className="text-lg font-semibold text-gray-900">{orgName}</h1>
              <div className="flex space-x-4 text-sm text-gray-600">
                <span>{manager}</span>
                <span className="hidden sm:block">|</span>
                <span className="hidden sm:block">{cin}</span>
              </div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => (
              <button
                key={item.name}
                className={`flex items-center space-x-1 px-3 py-2 rounded-md transition-colors ${
                  activeView === item.name
                    ? 'text-blue-600 bg-blue-50'
                    : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
                }`}
                onClick={() => handleNavClick(item.name)}
              >
                {item.icon}
                <span>{item.name}</span>
              </button>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6 text-gray-600" />
            ) : (
              <Menu className="h-6 w-6 text-gray-600" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <nav className="md:hidden py-4 border-t">
            {navItems.map((item) => (
              <button
                key={item.name}
                className={`flex items-center space-x-2 w-full px-4 py-2 transition-colors ${
                  activeView === item.name
                    ? 'text-blue-600 bg-blue-50'
                    : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
                }`}
                onClick={() => handleNavClick(item.name)}
              >
                {item.icon}
                <span>{item.name}</span>
              </button>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;