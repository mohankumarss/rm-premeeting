import React, { useState } from 'react';
import Header from './components/Header';
import SosView from './components/SosView';
import { Building2, Bell, ClipboardList, FileWarning } from 'lucide-react';

function App() {
  const [activeView, setActiveView] = useState('SOS');

  const orgDetails = {
    name: "Global Solutions Inc.",
    manager: "John Smith",
    cin: "L12345AB2024PLC098765"
  };

  const navItems = [
    { name: 'SOS', icon: <Bell className="w-4 h-4" /> },
    { name: 'FollowUp', icon: <ClipboardList className="w-4 h-4" /> },
    { name: 'NTC', icon: <FileWarning className="w-4 h-4" /> }
  ];

  const companySummary = {
    description: "Global Solutions Inc. is a leading technology solutions provider specializing in enterprise software and digital transformation.",
    industry: "Information Technology",
    founded: "2010",
    headquarters: "San Francisco, CA",
    employees: "500+",
    revenue: "$50M+"
  };

  const meetings = [
    {
      date: "2024-03-15",
      summary: "Quarterly business review - Discussed new product roadmap and expansion plans",
      type: "Strategic Review"
    },
    {
      date: "2024-03-01",
      summary: "Technical implementation meeting - Reviewed system architecture and deployment timeline",
      type: "Technical"
    },
    {
      date: "2024-02-15",
      summary: "Contract renewal discussion - Negotiated terms for the upcoming year",
      type: "Business"
    }
  ];

  const representatives = [
    {
      name: "Sarah Johnson",
      role: "Account Executive",
      email: "sarah.johnson@globalsolutions.com",
      phone: "+1 (555) 123-4567"
    },
    {
      name: "Michael Chen",
      role: "Technical Lead",
      email: "michael.chen@globalsolutions.com",
      phone: "+1 (555) 234-5678"
    },
    {
      name: "Emily Rodriguez",
      role: "Customer Success Manager",
      email: "emily.rodriguez@globalsolutions.com",
      phone: "+1 (555) 345-6789"
    },
    {
      name: "David Kim",
      role: "Solution Architect",
      email: "david.kim@globalsolutions.com",
      phone: "+1 (555) 456-7890"
    },
    {
      name: "Lisa Thompson",
      role: "Project Manager",
      email: "lisa.thompson@globalsolutions.com",
      phone: "+1 (555) 567-8901"
    },
    {
      name: "Robert Martinez",
      role: "Integration Specialist",
      email: "robert.martinez@globalsolutions.com",
      phone: "+1 (555) 678-9012"
    }
  ];

  const mainReasons = [
    {
      title: "Business Outlook",
      reasons: "Positive growth trajectory with planned expansion into APAC region",
      meetingType: "Strategic",
      representative: "Sarah Johnson",
      activityId: "BO-2024-001"
    },
    {
      title: "Upsell Followup",
      reasons: "Enterprise package upgrade discussion in progress",
      meetingType: "Sales",
      representative: "Emily Rodriguez",
      activityId: "UF-2024-015"
    },
    {
      title: "Lending Applications in Flight",
      reasons: "Working capital loan application under review",
      meetingType: "Financial",
      representative: "Michael Chen",
      activityId: "LA-2024-008"
    },
    {
      title: "Non Lending Applications",
      reasons: "Trade finance solutions implementation",
      meetingType: "Business",
      representative: "Lisa Thompson",
      activityId: "NL-2024-023"
    },
    {
      title: "Service Issues",
      reasons: "Minor system integration challenges being addressed",
      meetingType: "Technical",
      representative: "David Kim",
      activityId: "SI-2024-045"
    },
    {
      title: "Sector Related Information",
      reasons: "Tech sector growth analysis and market positioning",
      meetingType: "Analysis",
      representative: "Robert Martinez",
      activityId: "SR-2024-012"
    },
    {
      title: "Customer/Supplier Info",
      reasons: "Key partnership expansion with regional suppliers",
      meetingType: "Business",
      representative: "Sarah Johnson",
      activityId: "CS-2024-034"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        orgName={orgDetails.name}
        manager={orgDetails.manager}
        cin={orgDetails.cin}
        navItems={navItems}
        onNavClick={setActiveView}
        activeView={activeView}
      />
      <main className="container mx-auto px-4 py-8">
        {activeView === 'SOS' && (
          <SosView 
            companySummary={companySummary} 
            meetings={meetings} 
            representatives={representatives}
            mainReasons={mainReasons}
          />
        )}
      </main>
    </div>
  );
}

export default App;